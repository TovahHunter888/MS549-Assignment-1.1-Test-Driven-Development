#include <iostream>
#include <string>
#include "functions.h"

using namespace std;


int menu()
{
	int choice;
	cout << "Menu options" << endl;
	cout << "1. Happy New Year" << endl;
	cout << "2. Concat strings" << endl;
	cout << "3. exit" << endl;
	cin >> choice;
	return choice;

}
void happynewyear()
{
	for (int i = 10; i > 0; i--)
	{
		cout << "Count Down  = " << i << endl;
	}
}
void addStr(string str1, string str2)
{
	string str3 = str1 + str2;
	cout << "concat str = " << str3 << endl;
}