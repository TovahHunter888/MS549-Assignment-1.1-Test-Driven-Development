#pragma once
#include <string>

using namespace std;

int menu();
void happynewyear();
void addStr(string str1, string str2);




