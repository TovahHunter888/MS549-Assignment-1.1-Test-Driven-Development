/*
* Tovah Hunter
* week 1
* Assignment 1.1 Test Driven Development
* Estimate 1 hour
* Actual 1 hour 
* Analysis: The menu works without error. The while loop around the menu keeps the program running  until the exit is reached. There are three files. A functions.h that 
* shows the menu options. Functions.cpp file is where the functions for the menu options are described. Main.cpp is where we use if/else conditionals to for each menu option to follow.
*A library is created of items to include in each file. THe using namespace std tells the program when to run.
* 
*/

// libraries
#include <iostream>
#include <string>
#include "Functions.h"

using namespace std; 

int main()
{
	bool notDone = true;
	while (notDone)
	{

		int option = menu();
		//cout << "you chose     "  << option << "Do you want to continue?" << endl;
		if (option == 1)
		{
			happynewyear();
		}
		else if (option == 2)
		{
			addStr(" Happy", "Holiday");
		}
		else
		{
			notDone = false;
		}

	}
	return 0;
}